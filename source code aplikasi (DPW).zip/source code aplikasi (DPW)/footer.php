<div class="footer">
            <div class="container">
                <div class="row">
                   
                    <div class="col-md-2 col-xs-2">
                        <ul class="menu-item">
                 
                        </ul>
                    </div>
                    <div class="col-md-2 col-xs-6">
                        <ul class="menu-item">

                        </ul>
                    </div>
                    
            </div>
            <div class="container">
                <div class="mini-footer">
                    <div class="row">
                        <div class="col-md-6">
                            Copyright 2020 ME STORE &nbsp;  &nbsp;  &nbsp; 
                        </div>
                        <div class="col-md-6">
                            <div class="text-right">
                                <img src="images/elements/payment.png" alt="payment systems" />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- ======================================================================
                                        END FOOTER
        ======================================================================= -->

        <!-- ======================================================================
                                        START SCRIPTS
        ======================================================================= -->
        <script src="js/modernizr.custom.63321.js" type="text/javascript"></script>
        <script src="js/jquery-1.10.0.min.js" type="text/javascript"></script>
        <script src="js/jquery-ui.min.js" type="text/javascript"></script>
        <script src="js/bootstrap.js" type="text/javascript"></script>
        <script src="js/placeholder.js" type="text/javascript"></script>
        <script src="js/imagesloaded.pkgd.min.js" type="text/javascript"></script>
        <script src="js/masonry.pkgd.min.js" type="text/javascript"></script>
        <script src="js/jquery.swipebox.min.js" type="text/javascript"></script>
        <script src="js/farbtastic/farbtastic.js" type="text/javascript"></script>
        <script src="js/options.js" type="text/javascript"></script>
        <script src="js/plugins.js" type="text/javascript"></script>
        <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
          <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
        <![endif]-->
        <!-- ======================================================================
                                        END SCRIPTS
        ======================================================================= -->
        <!-- Select2 -->
        <script src="control/theme/plugins/select2/select2.full.min.js"></script>
        <script type="text/javascript">
            $(document).ready(function(){
                $('.select2').select2();
            });
        </script>
    </body>
</html>